# Cargar librerías necesarias
library(dplyr)
library(readr)

# Cargar los dataframes
indices_distritos <- read_csv("/Volumes/HD/minería_de_datos/Final/resultados/índices/2020/distritos_2020.csv")
tiempos_viaje <- read_csv("/Volumes/HD/minería_de_datos/Final/resultados/tiempo_viaje/promedios_dist_2017.csv")

# Unir los dataframes utilizando las llaves especificadas
data_unida <- indices_distritos %>%
  inner_join(tiempos_viaje, by = c("distrito" = "dto_origen"))

# Renombrar las variables clave para mayor claridad
data_unida <- data_unida %>%
  rename(
    indice_socioeconomico = indice_distrito,
    tiempo_viaje = prom_tiempo_viaje
  )

# Escalar el índice socioeconómico
data_unida$indice_socio_scaled <- scale(data_unida$indice_socioeconomico)

# Realizar la regresión lineal simple
# Modelo de regresión lineal
modelo <- lm(tiempo_viaje ~ indice_socio_scaled, data = data_unida)

# Resumen del modelo
summary(modelo)

# Visualización de la relación con un gráfico de dispersión y línea de regresión
library(ggplot2)

ggplot(data_unida, aes(x = indice_socio_scaled, y = tiempo_viaje)) +
  geom_point() +
  geom_smooth(method = "lm", color = "blue", se = TRUE) +
  labs(
    title = "Relación entre el índice socioeconómico y el tiempo de viaje",
    x = "Índice Socioeconómico",
    y = "Tiempo de Viaje Promedio (minutos)"
  ) +
  theme_minimal()
