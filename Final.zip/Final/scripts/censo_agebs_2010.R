##paqueterías##
library(readxl)
library(dplyr)
# Cargar los datos de la Ciudad de México
cdmx_libro1 <- read_excel("/Volumes/HD/minería_de_datos/Final/datos/Censo/2010/RESAGEBURB_09XLS10 .xls", sheet = 1)
cdmx_libro2 <- read_excel("/Volumes/HD/minería_de_datos/Final/datos/Censo/2010/RESAGEBURB_09XLS10 .xls", sheet = 2)

# Cargar los datos del Estado de México
edomex_libro1 <- read_excel("/Volumes/HD/minería_de_datos/Final/datos/Censo/2010/RESAGEBURB_15XLS10 2.xls", sheet = 1)
edomex_libro2 <- read_excel("/Volumes/HD/minería_de_datos/Final/datos/Censo/2010/RESAGEBURB_15XLS10 2.xls", sheet = 2)
edomex_libro3 <- read_excel("/Volumes/HD/minería_de_datos/Final/datos/Censo/2010/RESAGEBURB_15XLS10 2.xls", sheet = 3)
# Combinar todas las observaciones
datos_combinados <- bind_rows(cdmx_libro1, cdmx_libro2, edomex_libro1, edomex_libro2, edomex_libro3)
# Filtrar las filas con "Total AGEB urbana"
datos_filtrados <- datos_combinados %>%
  filter(NOM_LOC == "Total AGEB urbana")
# Crear la variable CVEGEO
datos_filtrados <- datos_filtrados %>%
  mutate(CVEGEO = paste0(ENTIDAD, MUN, LOC, AGEB))
##exportar##
# Exportar a un archivo CSV
write.csv(datos_filtrados, "/Volumes/HD/minería_de_datos/Final/resultados/censo_agebs/2010/censo_agebs.csv", row.names = FALSE)
