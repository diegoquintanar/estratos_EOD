setwd("/Volumes/HD/minería_de_datos/Final")
##paqueterías##
library(dplyr)
library(tidyr)
library(haven)
library(stringr)
library(survey)
##subimos la base de 2017##
EOD2017 <- read_sav("/Volumes/HD/minería_de_datos/Final/datos/tr_Trabajo_2017_FINAL.sav")
##revisamos la estructura del data frame##
str(EOD2017)
# Crear una nueva variable que indique qué medios de transporte utilizó la persona
EOD2017$medios_utilizados <- apply(EOD2017[, c("p5_14_01", "p5_14_02", "p5_14_03", "p5_14_04", 
                                               "p5_14_05", "p5_14_06", "p5_14_07", "p5_14_08", 
                                               "p5_14_09", "p5_14_10", "p5_14_11", "p5_14_12", 
                                               "p5_14_13", "p5_14_14", "p5_14_15", "p5_14_16", 
                                               "p5_14_17", "p5_14_18", "p5_14_19", "p5_14_20")], 
                                   1, function(x) paste(names(EOD2017[, c("p5_14_01", "p5_14_02", "p5_14_03", 
                                                                          "p5_14_04", "p5_14_05", "p5_14_06", 
                                                                          "p5_14_07", "p5_14_08", "p5_14_09", 
                                                                          "p5_14_10", "p5_14_11", "p5_14_12", 
                                                                          "p5_14_13", "p5_14_14", "p5_14_15", 
                                                                          "p5_14_16", "p5_14_17", "p5_14_18", 
                                                                          "p5_14_19", "p5_14_20")])[x == 1], collapse = ","))
# Definir los medios de transporte público
publico <- c("p5_14_02", "p5_14_04", "p5_14_05", "p5_14_06", "p5_14_08", "p5_14_10", "p5_14_11", "p5_14_12", "p5_14_13", "p5_14_15", "p5_14_16", "p5_14_17")
# Definir los medios de transporte privado
privado <- c("p5_14_01", "p5_14_03", "p5_14_07", "p5_14_09", "p5_14_18", "p5_14_19")
# Crear la nueva variable categórica
EOD2017$tipo_transporte <- NA
EOD2017$tipo_transporte[str_detect(EOD2017$medios_utilizados, paste(publico, collapse = "|"))] <- 1
EOD2017$tipo_transporte[is.na(EOD2017$tipo_transporte) & 
                          str_detect(EOD2017$medios_utilizados, paste(privado, collapse = "|"))] <- 2
##Si sólo caminó##
EOD2017$tipo_transporte[EOD2017$medios_utilizados == "p5_14_14"] <- 3
##Otros medios##
EOD2017$tipo_transporte[EOD2017$medios_utilizados == "p5_14_20"] <- 4
# Convertir las variables a factor##
EOD2017 <- EOD2017 %>%
  mutate(
    n_via = as.factor(n_via),
    p5_3 = as.factor(p5_3),
    tipo_transporte = as.factor(tipo_transporte),
    dto_dest = as.factor(dto_dest),
    dto_origen = as.factor(dto_origen)
  )
##aplicamos los filtros de interés##
nuevo_df <- EOD2017 %>% 
  filter(n_via == 1, 
         p5_3 == 1, 
         tipo_transporte == 1, 
         p5_13 == 2, 
         minstot < 360, 
         !dto_dest %in% c(999, 888))
# Calcular el promedio de tiempo de viaje por distrito
promedios_df <- nuevo_df %>%
  group_by(dto_origen) %>%
  summarise(prom_tiempo_viaje = mean(minstot, na.rm = TRUE))

# Unir la variable calculada al data frame original
nuevo_df <- nuevo_df %>%
  left_join(promedios_df, by = "dto_origen")
# Exportar promedios_df
write.csv(promedios_df, "/Volumes/HD/minería_de_datos/Final/resultados/promedios_dist_2017.csv", row.names = FALSE)

# Exportar nuevo_df
write.csv(nuevo_df, "/Volumes/HD/minería_de_datos/Final/resultados/filtrado_2017df.csv", row.names = FALSE)
