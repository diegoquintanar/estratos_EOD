# Cargar la base de datos
library(dplyr)

# Ruta del archivo CSV
ruta <- "/Volumes/HD/minería_de_datos/Final/resultados/base_completa/base_completa_2010.csv"

# Cargar los datos
base <- read.csv(ruta)

#estructura de los datos##
str(base$GRAPROES)

# Convertir las variables de interés a enteros
base <- base %>%
  mutate(
    PDER_SS = as.integer(PDER_SS),
    P15PRI_CO = as.integer(P15PRI_CO),
    P15SEC_CO = as.integer(P15SEC_CO),
    PEA = as.integer(PEA),
    VPH_PISODT = as.integer(VPH_PISODT),
    VPH_2YMASD = as.integer(VPH_2YMASD),
    VPH_3YMASC = as.integer(VPH_3YMASC),
    VPH_C_ELEC = as.integer(VPH_C_ELEC),
    VPH_AGUADV = as.integer(VPH_AGUADV),
    VPH_EXCSA = as.integer(VPH_EXCSA),
    VPH_DRENAJ = as.integer(VPH_DRENAJ),
    VPH_TV = as.integer(VPH_TV),
    VPH_AUTOM = as.integer(VPH_AUTOM),
    VPH_PC = as.integer(VPH_PC),
    VPH_CEL = as.integer(VPH_CEL),
    VPH_INTER = as.integer(VPH_INTER)
  )
# Crear las proporciones
base <- base %>%
  mutate(
    PPDER_SS = PDER_SS / POBTOT,
    PP15PRI_CO = P15PRI_CO / POBTOT,
    PP15SEC_CO = P15SEC_CO / POBTOT,
    PPEA = PEA / POBTOT,
    PVPH_PISODT = VPH_PISODT / VIVTOT,
    PVPH_2YMASD = VPH_2YMASD / VIVTOT,
    PVPH_3YMASC = VPH_3YMASC / VIVTOT,
    PVPH_C_ELEC = VPH_C_ELEC / VIVTOT,
    PVPH_AGUADV = VPH_AGUADV / VIVTOT,
    PVPH_EXCSA = VPH_EXCSA / VIVTOT,
    PVPH_DRENAJ = VPH_DRENAJ / VIVTOT,
    PVPH_TV = VPH_TV / VIVTOT,
    PVPH_AUTOM = VPH_AUTOM / VIVTOT,
    PVPH_PC = VPH_PC / VIVTOT,
    PVPH_CEL = VPH_CEL / VIVTOT,
    PVPH_INTER = VPH_INTER / VIVTOT
  )

# Crear un nuevo dataframe con las variables solicitadas
nueva_base <- base %>%
  select(
    GRAPROES, POBTOT, ENTIDAD, NOM_ENT, MUN, NOM_MUN, LOC, NOM_LOC,
    AGEB, MZA, cve_ageb, distrito, prom_tiempo_viaje,
    PPDER_SS, PP15PRI_CO, PP15SEC_CO, PPEA,
    PVPH_PISODT, PVPH_2YMASD, PVPH_3YMASC, PVPH_C_ELEC,
    PVPH_AGUADV, PVPH_EXCSA, PVPH_DRENAJ, PVPH_TV,
    PVPH_AUTOM, PVPH_PC, PVPH_CEL, PVPH_INTER
  )

# Calcular el índice socioeconómico a nivel AGEB
nueva_base <- nueva_base %>%
  mutate(
    indice_ageb = rowMeans(select(., PPDER_SS:PVPH_INTER, GRAPROES), na.rm = TRUE)
  )

# Escalar el índice a un rango de 0 a 1
nueva_base <- nueva_base %>%
  mutate(
    indice_ageb = (indice_ageb - min(indice_ageb, na.rm = TRUE)) / 
      (max(indice_ageb, na.rm = TRUE) - min(indice_ageb, na.rm = TRUE))
  )

# Calcular el índice socioeconómico a nivel distrito
# Asegurarse de que los AGEBS están correctamente agrupados por distrito
indice_distrito <- nueva_base %>%
  group_by(distrito) %>%
  summarise(
    indice_distrito = mean(indice_ageb, na.rm = TRUE)
  )

# Guardar los resultados
write.csv(nueva_base, "/Volumes/HD/minería_de_datos/Final/resultados/índices/agebs_2010.csv", row.names = FALSE)
write.csv(indice_distrito, "/Volumes/HD/minería_de_datos/Final/resultados/índices/distritos_2010.csv", row.names = FALSE)

