setwd("/Volumes/HD/minería_de_datos/Final")
##paqueterías##
library(dplyr)
library(tidyr)
library(lubridate)
library(readxl)
library(tidyr)
library(haven)
library(stringr)
library(survey)
library(sf)

########EOD 2007########


EOD2007<- read.csv("/Volumes/HD/minería_de_datos/Final/datos/EOD/tr_Trabajo_2007_POND_FINAL.csv", header = TRUE, sep = ",")
##la base tiene 232,317 registros de viaje con 132 variables##
##revisamos la estructura del data frame##
str(EOD2007)

##creamos la variable categórica sobre transporte público, privado u otro##
publico <- c("1", "2", "3", "4", "5", "6", "7", "8")

# Definir los modos de transporte privado
privado <- c("9", "A", "B")

# Definir el modo "otro"
otro <- "C"

# Crear la nueva variable categórica "tipo_transporte"
EOD2007 <- EOD2007 %>%
  mutate(
    # Evaluar si en la cadena se utilizó algún tipo de transporte
    tipo_transporte = case_when(
      # Si la persona utilizó al menos un transporte público
      grepl(paste(publico, collapse="|"), sordentran) ~ 1,
      
      # Si sólo se utilizaron transportes privados
      !grepl(paste(publico, collapse="|"), sordentran) & 
        grepl(paste(privado, collapse="|"), sordentran) ~ 2,
      
      # Si sólo se utilizó el transporte categorizado como "otro"
      grepl(paste(otro, collapse="|"), sordentran) & 
        !grepl(paste(publico, privado, collapse="|"), sordentran) ~ 3,
      
      # En caso de no haber coincidencia, asignar NA
      TRUE ~ NA_real_
    )
  )
# Convertir las variables a factor##
EOD2007 <- EOD2007 %>%
  mutate(
    nviaje = as.factor(nviaje),
    idtc_propo = as.factor(idtc_propo),
    tipo_transporte = as.factor(tipo_transporte),
    DTO_DES_17 = as.factor(DTO_DES_17),
    DTO_ORG_17 = as.factor(DTO_ORG_17)
  )
###calculamos la variable de minutos totales de viaje##
EOD2007$mins_tot <- hour(hms(EOD2007$tiempo_viaj)) * 60 + minute(hms(EOD2007$tiempo_viaj))
###creamos el nuevo dataframe con los filtros definitivos##
nuevo_df <- EOD2007 %>% 
  filter(nviaje == 1, 
         idtc_propo %in% c(1, 7), 
         tipo_transporte == 1, 
         mins_tot < 360, 
         !is.na(DTO_DES_17), 
         DTO_DES_17 != 998,
         DTO_DES_17 != 999)
# Calcular el promedio de tiempo de viaje por distrito
promedios_df <- nuevo_df %>%
  group_by(DTO_ORG_17) %>%
  summarise(prom_tiempo_viaje = mean(mins_tot, na.rm = TRUE))

# Unir la variable calculada al data frame original
nuevo_df <- nuevo_df %>%
  left_join(promedios_df, by = "DTO_ORG_17")
# Exportar promedios_df
write.csv(promedios_df, "/Volumes/HD/minería_de_datos/Final/resultados/promedios_dist_2007.csv", row.names = FALSE)

# Exportar nuevo_df
write.csv(nuevo_df, "/Volumes/HD/minería_de_datos/Final/resultados/filtrado_2007df.csv", row.names = FALSE)



########EOD 2017#######



EOD2017 <- read_sav("/Volumes/HD/minería_de_datos/Final/datos/EOD/tr_Trabajo_2017_FINAL.sav")
##revisamos la estructura del data frame##
str(EOD2017)
# Crear una nueva variable que indique qué medios de transporte utilizó la persona
EOD2017$medios_utilizados <- apply(EOD2017[, c("p5_14_01", "p5_14_02", "p5_14_03", "p5_14_04", 
                                               "p5_14_05", "p5_14_06", "p5_14_07", "p5_14_08", 
                                               "p5_14_09", "p5_14_10", "p5_14_11", "p5_14_12", 
                                               "p5_14_13", "p5_14_14", "p5_14_15", "p5_14_16", 
                                               "p5_14_17", "p5_14_18", "p5_14_19", "p5_14_20")], 
                                   1, function(x) paste(names(EOD2017[, c("p5_14_01", "p5_14_02", "p5_14_03", 
                                                                          "p5_14_04", "p5_14_05", "p5_14_06", 
                                                                          "p5_14_07", "p5_14_08", "p5_14_09", 
                                                                          "p5_14_10", "p5_14_11", "p5_14_12", 
                                                                          "p5_14_13", "p5_14_14", "p5_14_15", 
                                                                          "p5_14_16", "p5_14_17", "p5_14_18", 
                                                                          "p5_14_19", "p5_14_20")])[x == 1], collapse = ","))
# Definir los medios de transporte público
publico <- c("p5_14_02", "p5_14_04", "p5_14_05", "p5_14_06", "p5_14_08", "p5_14_10", "p5_14_11", "p5_14_12", "p5_14_13", "p5_14_15", "p5_14_16", "p5_14_17")
# Definir los medios de transporte privado
privado <- c("p5_14_01", "p5_14_03", "p5_14_07", "p5_14_09", "p5_14_18", "p5_14_19")
# Crear la nueva variable categórica
EOD2017$tipo_transporte <- NA
EOD2017$tipo_transporte[str_detect(EOD2017$medios_utilizados, paste(publico, collapse = "|"))] <- 1
EOD2017$tipo_transporte[is.na(EOD2017$tipo_transporte) & 
                          str_detect(EOD2017$medios_utilizados, paste(privado, collapse = "|"))] <- 2
##Si sólo caminó##
EOD2017$tipo_transporte[EOD2017$medios_utilizados == "p5_14_14"] <- 3
##Otros medios##
EOD2017$tipo_transporte[EOD2017$medios_utilizados == "p5_14_20"] <- 4
# Convertir las variables a factor##
EOD2017 <- EOD2017 %>%
  mutate(
    n_via = as.factor(n_via),
    p5_3 = as.factor(p5_3),
    tipo_transporte = as.factor(tipo_transporte),
    dto_dest = as.factor(dto_dest),
    dto_origen = as.factor(dto_origen)
  )
##aplicamos los filtros de interés##
nuevo_df <- EOD2017 %>% 
  filter(n_via == 1, 
         p5_3 == 1, 
         tipo_transporte == 1, 
         p5_13 == 2, 
         minstot < 360, 
         !dto_dest %in% c(999, 888))
# Calcular el promedio de tiempo de viaje por distrito
promedios_df <- nuevo_df %>%
  group_by(dto_origen) %>%
  summarise(prom_tiempo_viaje = mean(minstot, na.rm = TRUE))

# Unir la variable calculada al data frame original
nuevo_df <- nuevo_df %>%
  left_join(promedios_df, by = "dto_origen")
# Exportar promedios_df
write.csv(promedios_df, "/Volumes/HD/minería_de_datos/Final/resultados/promedios_dist_2017.csv", row.names = FALSE)

# Exportar nuevo_df
write.csv(nuevo_df, "/Volumes/HD/minería_de_datos/Final/resultados/filtrado_2017df.csv", row.names = FALSE)


#####VINCULAR AGEBS CON DISTRITOS########

###2010###
# Cargar la capa de AGEBS
agebs <- st_read("/Volumes/HD/minería_de_datos/Final/datos/Agebs/2010/agebs_2010.shp")

# Cargar la capa de distritos
distritos <- st_read("/Volumes/HD/minería_de_datos/Final/datos/Cartografía/PSIG_186_DTTO.shp")
# Calcular los centroides de los AGEBS
agebs_centroides <- st_centroid(agebs)
##Verificar los CRS de ambas capas##
st_crs(agebs_centroides)
st_crs(distritos)
##Transformar los CRS para que coincidan## 
##Esto transforma la capa distritos al CRS de agebs_centroides##
distritos <- st_transform(distritos, st_crs(agebs_centroides))
# Hacer el spatial join
agebs_distritos <- st_join(agebs_centroides, distritos, join = st_within)
# Convertir a data frame y seleccionar columnas relevantes
agebs_distritos_df <- agebs_distritos %>%
  st_drop_geometry() %>%
  select(cve_ageb = CVEGEO, distrito = Distrito)
# Exportar a un archivo CSV
write.csv(agebs_distritos_df, "/Volumes/HD/minería_de_datos/Final/resultados/agebs_distrito/agebs_distritos_2010.csv", row.names = FALSE)

##2020##
# Cargar la capa de AGEBS
agebs <- st_read("/Volumes/HD/minería_de_datos/Final/datos/Agebs/2020/agebs_2020.shp")
# Cargar la capa de distritos
distritos <- st_read("/Volumes/HD/minería_de_datos/Final/datos/Cartografía/PSIG_186_DTTO.shp")
# Calcular los centroides de los AGEBS
agebs_centroides <- st_centroid(agebs)
##Verificar los CRS de ambas capas##
st_crs(agebs_centroides)
st_crs(distritos)
##Transformar los CRS para que coincidan## 
##Esto transforma la capa distritos al CRS de agebs_centroides##
distritos <- st_transform(distritos, st_crs(agebs_centroides))
# Hacer el spatial join
agebs_distritos <- st_join(agebs_centroides, distritos, join = st_within)
# Convertir a data frame y seleccionar columnas relevantes
agebs_distritos_df <- agebs_distritos %>%
  st_drop_geometry() %>%
  select(cve_ageb = CVEGEO, distrito = Distrito)
# Exportar a un archivo CSV
write.csv(agebs_distritos_df, "/Volumes/HD/minería_de_datos/Final/resultados/agebs_distrito/agebs_distritos.csv", row.names = FALSE)



#######VINCULAR VARIABLES SOCIODEMOGRÁFICAS DEL CENSO CON AGEBS######



##2010##
# Cargar los datos de la Ciudad de México
cdmx_libro1 <- read_excel("/Volumes/HD/minería_de_datos/Final/datos/Censo/2010/RESAGEBURB_09XLS10 .xls", sheet = 1)
cdmx_libro2 <- read_excel("/Volumes/HD/minería_de_datos/Final/datos/Censo/2010/RESAGEBURB_09XLS10 .xls", sheet = 2)

# Cargar los datos del Estado de México
edomex_libro1 <- read_excel("/Volumes/HD/minería_de_datos/Final/datos/Censo/2010/RESAGEBURB_15XLS10 2.xls", sheet = 1)
edomex_libro2 <- read_excel("/Volumes/HD/minería_de_datos/Final/datos/Censo/2010/RESAGEBURB_15XLS10 2.xls", sheet = 2)
edomex_libro3 <- read_excel("/Volumes/HD/minería_de_datos/Final/datos/Censo/2010/RESAGEBURB_15XLS10 2.xls", sheet = 3)
# Combinar todas las observaciones
datos_combinados <- bind_rows(cdmx_libro1, cdmx_libro2, edomex_libro1, edomex_libro2, edomex_libro3)
# Filtrar las filas con "Total AGEB urbana"
datos_filtrados <- datos_combinados %>%
  filter(NOM_LOC == "Total AGEB urbana")
# Crear la variable CVEGEO
datos_filtrados <- datos_filtrados %>%
  mutate(CVEGEO = paste0(ENTIDAD, MUN, LOC, AGEB))
##exportar##
# Exportar a un archivo CSV
write.csv(datos_filtrados, "/Volumes/HD/minería_de_datos/Final/resultados/censo_agebs/2010/censo_agebs.csv", row.names = FALSE)

##2020##
# Cargar los datos de la Ciudad de México
cdmx_libro1 <- read_excel("/Volumes/HD/minería_de_datos/Final/datos/Censo/2020/RESAGEBURB_09XLSX20.xlsx")
# Cargar los datos del Estado de México
edomex_libro1 <- read_excel("/Volumes/HD/minería_de_datos/Final/datos/Censo/2020/RESAGEBURB_15XLSX20.xlsx")
# Combinar todas las observaciones
datos_combinados <- bind_rows(cdmx_libro1, edomex_libro1)
# Filtrar las filas con "Total AGEB urbana"
datos_filtrados <- datos_combinados %>%
  filter(NOM_LOC == "Total AGEB urbana")
# Crear la variable CVEGEO
datos_filtrados <- datos_filtrados %>%
  mutate(CVEGEO = paste0(ENTIDAD, MUN, LOC, AGEB))
# Exportar a un archivo CSV
write.csv(datos_filtrados, "/Volumes/HD/minería_de_datos/Final/resultados/censo_agebs/2020/censo_agebs.csv", row.names = FALSE)


########UNIR DATA FRAMES###########
# Leer los data frames
agebs_distritos <- read.csv("/Volumes/HD/minería_de_datos/Final/resultados/agebs_distrito/agebs_distritos_2010.csv")
censo_agebs <- read.csv("/Volumes/HD/minería_de_datos/Final/resultados/censo_agebs/2010/censo_agebs_2010.csv")
promedios_viaje <- read.csv("/Volumes/HD/minería_de_datos/Final/resultados/tiempo_viaje/promedios_dist_2007.csv")

# Unión de los primeros dos data frames
base_combinada <- agebs_distritos %>%
  inner_join(censo_agebs, by = c("cve_ageb" = "CVEGEO"))

# Transformar DTO_ORG_17 en la base promedios_viaje para que tenga formato de texto de longitud 3
promedios_viaje <- promedios_viaje %>%
  mutate(DTO_ORG_17 = sprintf("%03d", DTO_ORG_17))

##convertimos a carácter la variable de distrito##
base_combinada <- base_combinada %>%
  mutate(distrito = as.character(distrito))

# Unión con el tercer data frame
base_final <- base_combinada %>%
  inner_join(promedios_viaje, by = c("distrito" = "DTO_ORG_17"))

# Exportar el resultado final
write_csv(base_final, "/Volumes/HD/minería_de_datos/Final/resultados/base_completa/base_completa.csv")


##2020##
# Leer los data frames
agebs_distritos <- read.csv("/Volumes/HD/minería_de_datos/Final/resultados/agebs_distrito/agebs_distritos_2020.csv")
censo_agebs <- read.csv("/Volumes/HD/minería_de_datos/Final/resultados/censo_agebs/2020/censo_agebs_2020.csv")
promedios_viaje <- read.csv("/Volumes/HD/minería_de_datos/Final/resultados/tiempo_viaje/promedios_dist_2017.csv")
# Unión de los primeros dos data frames
base_combinada <- agebs_distritos %>%
  inner_join(censo_agebs, by = c("cve_ageb" = "CVEGEO"))
# Transformar DTO_ORG_17 en la base promedios_viaje para que tenga formato de texto de longitud 3
promedios_viaje <- promedios_viaje %>%
  mutate(dto_origen = sprintf("%03d", dto_origen))
##convertimos a carácter la variable de distrito##
base_combinada <- base_combinada %>%
  mutate(distrito = as.character(distrito))
# Unión con el tercer data frame
base_final <- base_combinada %>%
  inner_join(promedios_viaje, by = c("distrito" = "dto_origen"))
# Exportar el resultado final
write_csv(base_final, "/Volumes/HD/minería_de_datos/Final/resultados/base_completa/base_completa.csv")



#########CALCULAR ÍNDICES#########



##2010##
# Ruta del archivo CSV
ruta <- "/Volumes/HD/minería_de_datos/Final/resultados/base_completa/base_completa_2010.csv"

# Cargar los datos
base <- read.csv(ruta)

#estructura de los datos##
str(base$GRAPROES)

# Convertir las variables de interés a enteros
base <- base %>%
  mutate(
    PDER_SS = as.integer(PDER_SS),
    P15PRI_CO = as.integer(P15PRI_CO),
    P15SEC_CO = as.integer(P15SEC_CO),
    PEA = as.integer(PEA),
    VPH_PISODT = as.integer(VPH_PISODT),
    VPH_2YMASD = as.integer(VPH_2YMASD),
    VPH_3YMASC = as.integer(VPH_3YMASC),
    VPH_C_ELEC = as.integer(VPH_C_ELEC),
    VPH_AGUADV = as.integer(VPH_AGUADV),
    VPH_EXCSA = as.integer(VPH_EXCSA),
    VPH_DRENAJ = as.integer(VPH_DRENAJ),
    VPH_TV = as.integer(VPH_TV),
    VPH_AUTOM = as.integer(VPH_AUTOM),
    VPH_PC = as.integer(VPH_PC),
    VPH_CEL = as.integer(VPH_CEL),
    VPH_INTER = as.integer(VPH_INTER)
  )
# Crear las proporciones
base <- base %>%
  mutate(
    PPDER_SS = PDER_SS / POBTOT,
    PP15PRI_CO = P15PRI_CO / POBTOT,
    PP15SEC_CO = P15SEC_CO / POBTOT,
    PPEA = PEA / POBTOT,
    PVPH_PISODT = VPH_PISODT / VIVTOT,
    PVPH_2YMASD = VPH_2YMASD / VIVTOT,
    PVPH_3YMASC = VPH_3YMASC / VIVTOT,
    PVPH_C_ELEC = VPH_C_ELEC / VIVTOT,
    PVPH_AGUADV = VPH_AGUADV / VIVTOT,
    PVPH_EXCSA = VPH_EXCSA / VIVTOT,
    PVPH_DRENAJ = VPH_DRENAJ / VIVTOT,
    PVPH_TV = VPH_TV / VIVTOT,
    PVPH_AUTOM = VPH_AUTOM / VIVTOT,
    PVPH_PC = VPH_PC / VIVTOT,
    PVPH_CEL = VPH_CEL / VIVTOT,
    PVPH_INTER = VPH_INTER / VIVTOT
  )

# Crear un nuevo dataframe con las variables solicitadas
nueva_base <- base %>%
  select(
    GRAPROES, POBTOT, ENTIDAD, NOM_ENT, MUN, NOM_MUN, LOC, NOM_LOC,
    AGEB, MZA, cve_ageb, distrito, prom_tiempo_viaje,
    PPDER_SS, PP15PRI_CO, PP15SEC_CO, PPEA,
    PVPH_PISODT, PVPH_2YMASD, PVPH_3YMASC, PVPH_C_ELEC,
    PVPH_AGUADV, PVPH_EXCSA, PVPH_DRENAJ, PVPH_TV,
    PVPH_AUTOM, PVPH_PC, PVPH_CEL, PVPH_INTER
  )

# Calcular el índice socioeconómico a nivel AGEB
nueva_base <- nueva_base %>%
  mutate(
    indice_ageb = rowMeans(select(., PPDER_SS:PVPH_INTER, GRAPROES), na.rm = TRUE)
  )

# Escalar el índice a un rango de 0 a 1
nueva_base <- nueva_base %>%
  mutate(
    indice_ageb = (indice_ageb - min(indice_ageb, na.rm = TRUE)) / 
      (max(indice_ageb, na.rm = TRUE) - min(indice_ageb, na.rm = TRUE))
  )

# Calcular el índice socioeconómico a nivel distrito
# Asegurarse de que los AGEBS están correctamente agrupados por distrito
indice_distrito <- nueva_base %>%
  group_by(distrito) %>%
  summarise(
    indice_distrito = mean(indice_ageb, na.rm = TRUE)
  )

# Guardar los resultados
write.csv(nueva_base, "/Volumes/HD/minería_de_datos/Final/resultados/índices/agebs_2010.csv", row.names = FALSE)
write.csv(indice_distrito, "/Volumes/HD/minería_de_datos/Final/resultados/índices/distritos_2010.csv", row.names = FALSE)

##2020##

# Ruta del archivo CSV
ruta <- "/Volumes/HD/minería_de_datos/Final/resultados/base_completa/base_completa_2020.csv"
# Cargar los datos
base <- read.csv(ruta)
#estructura de los datos##
str(base$GRAPROES)
# Convertir las variables de interés a enteros
base <- base %>%
  mutate(
    PDER_SS = as.integer(PDER_SS),
    P15PRI_CO = as.integer(P15PRI_CO),
    P15SEC_CO = as.integer(P15SEC_CO),
    PEA = as.integer(PEA),
    VPH_PISODT = as.integer(VPH_PISODT),
    VPH_2YMASD = as.integer(VPH_2YMASD),
    VPH_3YMASC = as.integer(VPH_3YMASC),
    VPH_C_ELEC = as.integer(VPH_C_ELEC),
    VPH_AGUADV = as.integer(VPH_AGUADV),
    VPH_EXCSA = as.integer(VPH_EXCSA),
    VPH_DRENAJ = as.integer(VPH_DRENAJ),
    VPH_TV = as.integer(VPH_TV),
    VPH_AUTOM = as.integer(VPH_AUTOM),
    VPH_PC = as.integer(VPH_PC),
    VPH_CEL = as.integer(VPH_CEL),
    VPH_INTER = as.integer(VPH_INTER),
    GRAPROES = as.integer(GRAPROES)
  )
# Crear las proporciones
base <- base %>%
  mutate(
    PPDER_SS = PDER_SS / POBTOT,
    PP15PRI_CO = P15PRI_CO / POBTOT,
    PP15SEC_CO = P15SEC_CO / POBTOT,
    PPEA = PEA / POBTOT,
    PVPH_PISODT = VPH_PISODT / VIVTOT,
    PVPH_2YMASD = VPH_2YMASD / VIVTOT,
    PVPH_3YMASC = VPH_3YMASC / VIVTOT,
    PVPH_C_ELEC = VPH_C_ELEC / VIVTOT,
    PVPH_AGUADV = VPH_AGUADV / VIVTOT,
    PVPH_EXCSA = VPH_EXCSA / VIVTOT,
    PVPH_DRENAJ = VPH_DRENAJ / VIVTOT,
    PVPH_TV = VPH_TV / VIVTOT,
    PVPH_AUTOM = VPH_AUTOM / VIVTOT,
    PVPH_PC = VPH_PC / VIVTOT,
    PVPH_CEL = VPH_CEL / VIVTOT,
    PVPH_INTER = VPH_INTER / VIVTOT
  )

# Crear un nuevo dataframe con las variables solicitadas
nueva_base <- base %>%
  select(
    GRAPROES, POBTOT, ENTIDAD, NOM_ENT, MUN, NOM_MUN, LOC, NOM_LOC,
    AGEB, MZA, cve_ageb, distrito, prom_tiempo_viaje,
    PPDER_SS, PP15PRI_CO, PP15SEC_CO, PPEA,
    PVPH_PISODT, PVPH_2YMASD, PVPH_3YMASC, PVPH_C_ELEC,
    PVPH_AGUADV, PVPH_EXCSA, PVPH_DRENAJ, PVPH_TV,
    PVPH_AUTOM, PVPH_PC, PVPH_CEL, PVPH_INTER
  )

# Calcular el índice socioeconómico a nivel AGEB
nueva_base <- nueva_base %>%
  mutate(
    indice_ageb = rowMeans(select(., PPDER_SS:PVPH_INTER, GRAPROES), na.rm = TRUE)
  )

# Escalar el índice a un rango de 0 a 1
nueva_base <- nueva_base %>%
  mutate(
    indice_ageb = (indice_ageb - min(indice_ageb, na.rm = TRUE)) / 
      (max(indice_ageb, na.rm = TRUE) - min(indice_ageb, na.rm = TRUE))
  )

# Calcular el índice socioeconómico a nivel distrito
# Asegurarse de que los AGEBS están correctamente agrupados por distrito
indice_distrito <- nueva_base %>%
  group_by(distrito) %>%
  summarise(
    indice_distrito = mean(indice_ageb, na.rm = TRUE)
  )

# Guardar los resultados
write.csv(nueva_base, "/Volumes/HD/minería_de_datos/Final/resultados/índices/agebs_2020.csv", row.names = FALSE)
write.csv(indice_distrito, "/Volumes/HD/minería_de_datos/Final/resultados/índices/distritos_2020.csv", row.names = FALSE)



######REGRESIÓN LINEAL#########

##2010##

# Cargar los dataframes
indices_distritos <- read.csv("/Volumes/HD/minería_de_datos/Final/resultados/índices/2010/distritos_2010.csv")
tiempos_viaje <- read.csv("/Volumes/HD/minería_de_datos/Final/resultados/tiempo_viaje/promedios_dist_2007.csv")

# Unir los dataframes utilizando las llaves especificadas
data_unida <- indices_distritos %>%
  inner_join(tiempos_viaje, by = c("distrito" = "DTO_ORG_17"))

# Visualizar un resumen de la base unida para verificar la unión
summary(data_unida)

# Renombrar las variables clave para mayor claridad
data_unida <- data_unida %>%
  rename(
    indice_socioeconomico = indice_distrito,
    tiempo_viaje = prom_tiempo_viaje
  )

# Escalar el índice socioeconómico
data_unida$indice_socio_scaled <- scale(data_unida$indice_socioeconomico)

# Realizar la regresión lineal simple
# Modelo de regresión lineal
modelo <- lm(tiempo_viaje ~ indice_socio_scaled, data = data_unida)

# Resumen del modelo
summary(modelo)

# Visualización de la relación con un gráfico de dispersión y línea de regresión
library(ggplot2)

ggplot(data_unida, aes(x = indice_socio_scaled, y = tiempo_viaje)) +
  geom_point() +
  geom_smooth(method = "lm", color = "blue", se = TRUE) +
  labs(
    title = "Relación entre el índice socioeconómico y el tiempo de viaje",
    x = "Índice Socioeconómico",
    y = "Tiempo de Viaje Promedio (minutos)"
  ) +
  theme_minimal()

##2020##
# Cargar los dataframes
indices_distritos <- read.csv("/Volumes/HD/minería_de_datos/Final/resultados/índices/2020/distritos_2020.csv")
tiempos_viaje <- read.csv("/Volumes/HD/minería_de_datos/Final/resultados/tiempo_viaje/promedios_dist_2017.csv")

# Unir los dataframes utilizando las llaves especificadas
data_unida <- indices_distritos %>%
  inner_join(tiempos_viaje, by = c("distrito" = "dto_origen"))

# Renombrar las variables clave para mayor claridad
data_unida <- data_unida %>%
  rename(
    indice_socioeconomico = indice_distrito,
    tiempo_viaje = prom_tiempo_viaje
  )

# Escalar el índice socioeconómico
data_unida$indice_socio_scaled <- scale(data_unida$indice_socioeconomico)

# Realizar la regresión lineal simple
# Modelo de regresión lineal
modelo <- lm(tiempo_viaje ~ indice_socio_scaled, data = data_unida)

# Resumen del modelo
summary(modelo)

# Visualización de la relación con un gráfico de dispersión y línea de regresión
library(ggplot2)

ggplot(data_unida, aes(x = indice_socio_scaled, y = tiempo_viaje)) +
  geom_point() +
  geom_smooth(method = "lm", color = "blue", se = TRUE) +
  labs(
    title = "Relación entre el índice socioeconómico y el tiempo de viaje",
    x = "Índice Socioeconómico",
    y = "Tiempo de Viaje Promedio (minutos)"
  ) +
  theme_minimal()

