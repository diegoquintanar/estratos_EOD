##paqueterías##
library(readxl)
library(dplyr)
# Cargar los datos de la Ciudad de México
cdmx_libro1 <- read_excel("/Volumes/HD/minería_de_datos/Final/datos/Censo/2020/RESAGEBURB_09XLSX20.xlsx")
# Cargar los datos del Estado de México
edomex_libro1 <- read_excel("/Volumes/HD/minería_de_datos/Final/datos/Censo/2020/RESAGEBURB_15XLSX20.xlsx")
# Combinar todas las observaciones
datos_combinados <- bind_rows(cdmx_libro1, edomex_libro1)
# Filtrar las filas con "Total AGEB urbana"
datos_filtrados <- datos_combinados %>%
  filter(NOM_LOC == "Total AGEB urbana")
# Crear la variable CVEGEO
datos_filtrados <- datos_filtrados %>%
  mutate(CVEGEO = paste0(ENTIDAD, MUN, LOC, AGEB))
# Exportar a un archivo CSV
write.csv(datos_filtrados, "/Volumes/HD/minería_de_datos/Final/resultados/censo_agebs/2020/censo_agebs.csv", row.names = FALSE)
