#paqueterías#
library(sf)
library(dplyr)

# Cargar la capa de AGEBS
agebs <- st_read("/Volumes/HD/minería_de_datos/Final/datos/Agebs/2020/agebs_2020.shp")
# Cargar la capa de distritos
distritos <- st_read("/Volumes/HD/minería_de_datos/Final/datos/Cartografía/PSIG_186_DTTO.shp")
# Calcular los centroides de los AGEBS
agebs_centroides <- st_centroid(agebs)
##Verificar los CRS de ambas capas##
st_crs(agebs_centroides)
st_crs(distritos)
##Transformar los CRS para que coincidan## 
##Esto transforma la capa distritos al CRS de agebs_centroides##
distritos <- st_transform(distritos, st_crs(agebs_centroides))
# Hacer el spatial join
agebs_distritos <- st_join(agebs_centroides, distritos, join = st_within)
# Convertir a data frame y seleccionar columnas relevantes
agebs_distritos_df <- agebs_distritos %>%
  st_drop_geometry() %>%
  select(cve_ageb = CVEGEO, distrito = Distrito)
# Exportar a un archivo CSV
write.csv(agebs_distritos_df, "/Volumes/HD/minería_de_datos/Final/resultados/agebs_distrito/agebs_distritos.csv", row.names = FALSE)
