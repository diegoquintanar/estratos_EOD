setwd("/Volumes/HD/minería_de_datos/Final")
##paqueterías##
library(dplyr)
library(tidyr)
library(lubridate)
library(readxl)
##subimos la base de datos EOD2007 con la distritación de 2007##
EOD2007<- read.csv("/Volumes/HD/minería_de_datos/Final/datos/tr_Trabajo_2007_POND_FINAL.csv", header = TRUE, sep = ",")
##la base tiene 232,317 registros de viaje con 132 variables##
##revisamos la estructura del data frame##
str(EOD2007)
# Separar la variable sordentran en 7 nuevas columnas (tramos)
EOD2007 <- EOD2007 %>%
  separate(sordentran, into = c("tramo_1", "tramo_2", "tramo_3", "tramo_4", "tramo_5", "tramo_6", "tramo_7"), sep = c(1,2,3,4,5,6,7))
##calculamos las frecuencias para tipo de transporte con y sin factor de expansión##

##creamos la variable categórica sobre transporte público, privado u otro##
publico <- c("1", "2", "3", "4", "5", "6", "7", "8")

# Definir los modos de transporte privado
privado <- c("9", "A", "B")

# Definir el modo "otro"
otro <- "C"

# Crear la nueva variable categórica "tipo_transporte"
EOD2007 <- EOD2007 %>%
  mutate(
    # Evaluar si en la cadena se utilizó algún tipo de transporte
    tipo_transporte = case_when(
      # Si la persona utilizó al menos un transporte público
      grepl(paste(publico, collapse="|"), sordentran) ~ 1,
      
      # Si sólo se utilizaron transportes privados
      !grepl(paste(publico, collapse="|"), sordentran) & 
        grepl(paste(privado, collapse="|"), sordentran) ~ 2,
      
      # Si sólo se utilizó el transporte categorizado como "otro"
      grepl(paste(otro, collapse="|"), sordentran) & 
        !grepl(paste(publico, privado, collapse="|"), sordentran) ~ 3,
      
      # En caso de no haber coincidencia, asignar NA
      TRUE ~ NA_real_
    )
  )
# Convertir las variables a factor##
EOD2007 <- EOD2007 %>%
  mutate(
    nviaje = as.factor(nviaje),
    idtc_propo = as.factor(idtc_propo),
    tipo_transporte = as.factor(tipo_transporte),
    DTO_DES_17 = as.factor(DTO_DES_17),
    DTO_ORG_17 = as.factor(DTO_ORG_17)
  )
###calculamos la variable de minutos totales de viaje##
EOD2007$mins_tot <- hour(hms(EOD2007$tiempo_viaj)) * 60 + minute(hms(EOD2007$tiempo_viaj))
###creamos el nuevo dataframe con los filtros definitivos##
nuevo_df <- EOD2007 %>% 
  filter(nviaje == 1, 
         idtc_propo %in% c(1, 7), 
         tipo_transporte == 1, 
         mins_tot < 360, 
         !is.na(DTO_DES_17), 
         DTO_DES_17 != 998,
         DTO_DES_17 != 999)
# Calcular el promedio de tiempo de viaje por distrito
promedios_df <- nuevo_df %>%
  group_by(DTO_ORG_17) %>%
  summarise(prom_tiempo_viaje = mean(mins_tot, na.rm = TRUE))

# Unir la variable calculada al data frame original
nuevo_df <- nuevo_df %>%
  left_join(promedios_df, by = "DTO_ORG_17")
# Exportar promedios_df
write.csv(promedios_df, "/Volumes/HD/minería_de_datos/Final/resultados/promedios_dist_2007.csv", row.names = FALSE)

# Exportar nuevo_df
write.csv(nuevo_df, "/Volumes/HD/minería_de_datos/Final/resultados/filtrado_2007df.csv", row.names = FALSE)
