# Cargar librerías necesarias
library(dplyr)
library(readr)
# Leer los data frames
agebs_distritos <- read_csv("/Volumes/HD/minería_de_datos/Final/resultados/agebs_distrito/agebs_distritos_2020.csv")
censo_agebs <- read_csv("/Volumes/HD/minería_de_datos/Final/resultados/censo_agebs/2020/censo_agebs_2020.csv")
promedios_viaje <- read_csv("/Volumes/HD/minería_de_datos/Final/resultados/tiempo_viaje/promedios_dist_2017.csv")
# Unión de los primeros dos data frames
base_combinada <- agebs_distritos %>%
  inner_join(censo_agebs, by = c("cve_ageb" = "CVEGEO"))
# Transformar DTO_ORG_17 en la base promedios_viaje para que tenga formato de texto de longitud 3
promedios_viaje <- promedios_viaje %>%
  mutate(dto_origen = sprintf("%03d", dto_origen))
# Unión con el tercer data frame
base_final <- base_combinada %>%
  inner_join(promedios_viaje, by = c("distrito" = "dto_origen"))
# Exportar el resultado final
write_csv(base_final, "/Volumes/HD/minería_de_datos/Final/resultados/base_completa/base_completa.csv")
